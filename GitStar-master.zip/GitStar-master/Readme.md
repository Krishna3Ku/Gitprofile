# Gitstar : know yourself better


## How to run

Download ZIP or Clone the repository
Navigate to the directory

### Web view
![Gitstar](![2019-06-25 (3)](https://user-images.githubusercontent.com/30342542/60103276-eda0fb80-977c-11e9-99a2-2e9e61f74bfb.png)
)

### Mobile view
![Gitstar](![ezgif com-video-to-gif](https://user-images.githubusercontent.com/30342542/60104064-53da4e00-977e-11e9-8a31-b75a06e5ef7a.gif)
)


## Deployment

I have used Heroku for deployment purpose.

## Built With

* HTML5
* CSS
* Javascript
* jquery
* node.js
* express.js



## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* My main motivation behind this project was to work on APIs
